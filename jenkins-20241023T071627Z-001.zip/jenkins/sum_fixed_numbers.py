# sum_fixed_numbers.py

def main():
    first = 10
    second = 20

    # Add the two numbers
    sum_ = first + second

    # Print the result
    print(f"{first} + {second} = {sum_}")

if __name__ == "__main__":
    main()
